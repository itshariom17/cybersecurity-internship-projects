import unittest
from vapt.assessment import assess
from password_lab.passwords import make_record, verify, dictionary_attack, brute_candidates


class VAPTTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runs = {mode: {t['test']: t for t in assess(mode)['evidence']} for mode in ('vulnerable', 'fixed')}

    def test_sql_injection_and_remediation(self):
        self.assertEqual(self.runs['vulnerable']['sql_injection_login_bypass']['status'], 200)
        self.assertEqual(self.runs['fixed']['sql_injection_login_bypass']['status'], 401)

    def test_idor_and_remediation(self):
        self.assertEqual(self.runs['vulnerable']['idor_other_users_note']['response']['body'], 'Bob synthetic private note')
        self.assertEqual(self.runs['fixed']['idor_other_users_note']['status'], 403)
        self.assertNotIn('body', self.runs['fixed']['idor_other_users_note']['response'])

    def test_authentication_controls(self):
        for run in self.runs.values():
            self.assertEqual(run['unauthenticated_access']['status'], 401)
            self.assertEqual(run['invalid_login']['status'], 401)
            self.assertEqual(run['valid_login']['status'], 200)
            self.assertEqual(run['own_note']['status'], 200)

    def test_invalid_objects(self):
        for run in self.runs.values():
            self.assertEqual(run['missing_note']['status'], 404)
            self.assertEqual(run['malformed_note_id']['status'], 400)


class PasswordTests(unittest.TestCase):
    def test_sha256_known_vector(self):
        self.assertEqual(make_record('abc', 'sha256')['digest'],
                         'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')

    def test_all_verifiers(self):
        for algorithm in ('sha256', 'salted_sha256', 'pbkdf2_sha256'):
            record = make_record('lab-password', algorithm)
            self.assertTrue(verify('lab-password', record))
            self.assertFalse(verify('wrong-password', record))

    def test_unique_salts(self):
        first, second = make_record('same'), make_record('same')
        self.assertNotEqual(first['salt'], second['salt'])
        self.assertNotEqual(first['digest'], second['digest'])

    def test_dictionary_success_and_failure(self):
        record = make_record('demo', 'sha256')
        self.assertEqual(dictionary_attack(record, ['no', 'demo'])['attempts'], 2)
        self.assertIsNone(dictionary_attack(record, ['no'])['recovered'])

    def test_attempt_limit(self):
        result = dictionary_attack(make_record('demo', 'sha256'), ['no', 'demo'], 1)
        self.assertIsNone(result['recovered'])
        self.assertEqual(result['attempts'], 1)

    def test_brute_force(self):
        result = dictionary_attack(make_record('042', 'sha256'), brute_candidates())
        self.assertEqual(result['recovered'], '042')
        self.assertEqual(result['attempts'], 43)

    def test_invalid_search_space(self):
        for alphabet, length in [('', 3), ('001', 3), ('0123456789abcdef', 6)]:
            with self.assertRaises(ValueError):
                brute_candidates(alphabet, length)

    def test_unicode(self):
        record = make_record('caf\u00e9-\u2603', 'salted_sha256')
        self.assertTrue(verify('caf\u00e9-\u2603', record))


if __name__ == '__main__':
    unittest.main()
