"""Bounded offline password experiments using synthetic credentials only."""
import hashlib
import hmac
import itertools
import json
import secrets
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path

ITERATIONS = 600000


def make_record(password, algorithm='pbkdf2_sha256', salt=None, iterations=ITERATIONS):
    if algorithm not in ('sha256', 'salted_sha256', 'pbkdf2_sha256'):
        raise ValueError('Unsupported algorithm')
    if not isinstance(iterations, int) or iterations < 1:
        raise ValueError('Iterations must be positive')
    salt = b'' if algorithm == 'sha256' else (secrets.token_bytes(16) if salt is None else salt)
    if algorithm != 'sha256' and len(salt) < 16:
        raise ValueError('Use at least 16 salt bytes')
    value = password.encode('utf-8')
    digest = (hashlib.pbkdf2_hmac('sha256', value, salt, iterations) if algorithm == 'pbkdf2_sha256'
              else hashlib.sha256(salt + value).digest())
    return dict(algorithm=algorithm, salt=salt.hex(), iterations=iterations if algorithm == 'pbkdf2_sha256' else 1,
                digest=digest.hex())


def verify(password, record):
    candidate = make_record(password, record['algorithm'], bytes.fromhex(record['salt']), record['iterations'])
    return hmac.compare_digest(candidate['digest'], record['digest'])


def dictionary_attack(record, candidates, max_attempts=10000):
    if max_attempts < 1:
        raise ValueError('Attempt limit must be positive')
    start = time.perf_counter()
    attempts = 0
    for candidate in itertools.islice(candidates, max_attempts):
        attempts += 1
        if verify(candidate, record):
            return dict(recovered=candidate, attempts=attempts, elapsed_seconds=time.perf_counter() - start)
    return dict(recovered=None, attempts=attempts, elapsed_seconds=time.perf_counter() - start)


def brute_candidates(alphabet='0123456789', length=3):
    if not alphabet or len(set(alphabet)) != len(alphabet) or not 1 <= length <= 6:
        raise ValueError('Use a unique non-empty alphabet and length 1 to 6')
    if len(alphabet) ** length > 1000000:
        raise ValueError('Lab search space exceeds one million candidates')
    return (''.join(chars) for chars in itertools.product(alphabet, repeat=length))


def run_experiment():
    words = ['password', 'welcome', 'letmein', 'lab-only-42', 'summer']
    records, attacks, benchmark = {}, {}, {}
    for algorithm in ('sha256', 'salted_sha256', 'pbkdf2_sha256'):
        record = make_record('lab-only-42', algorithm)
        records[algorithm] = record
        attacks[algorithm] = dictionary_attack(record, words)
        samples = []
        for _ in range(5):
            start = time.perf_counter()
            verify('incorrect-test-password', record)
            samples.append(time.perf_counter() - start)
        benchmark[algorithm] = {'median_verification_seconds': statistics.median(samples), 'samples': 5}
    first = make_record('same-demo-password', 'salted_sha256')
    second = make_record('same-demo-password', 'salted_sha256')
    return dict(generated_utc=datetime.now(timezone.utc).isoformat(),
                dataset='Synthetic credentials generated locally; no leaked or external credentials',
                records=records, dictionary_attacks=attacks, benchmark=benchmark,
                brute_force=dictionary_attack(make_record('042', 'sha256'), brute_candidates()),
                absent_candidate=dictionary_attack(make_record('outside-list', 'sha256'), words),
                salt_demo={'same_password': True, 'different_salts': first['salt'] != second['salt'],
                           'different_digests': first['digest'] != second['digest']},
                caveat='CPU-only single-process measurements; not GPU cracking speeds or population-level conclusions.')


def main():
    results = run_experiment()
    Path('password_lab/results.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
