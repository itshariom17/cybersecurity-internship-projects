"""Deliberately vulnerable, loopback-only training API. Never deploy publicly."""
import argparse
import json
import secrets
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit, parse_qs


def create_server(mode='fixed', port=0):
    if mode not in ('vulnerable', 'fixed'):
        raise ValueError('Unknown mode')
    db = sqlite3.connect(':memory:', check_same_thread=False)
    db.executescript('''
        CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT);
        INSERT INTO users VALUES (1, 'alice', 'Alice-lab-only!'), (2, 'bob', 'Bob-lab-only!');
        CREATE TABLE notes (id INTEGER PRIMARY KEY, owner INTEGER, body TEXT);
        INSERT INTO notes VALUES (1, 1, 'Alice synthetic note'), (2, 2, 'Bob synthetic private note');
    ''')
    sessions = {}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def reply(self, status, data):
            payload = json.dumps(data).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(payload)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(payload)

        def do_POST(self):
            if self.path != '/login':
                return self.reply(404, {'error': 'Not found'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 4096:
                    return self.reply(400, {'error': 'Invalid request size'})
                data = json.loads(self.rfile.read(size))
                username, password = data['username'], data['password']
                if not isinstance(username, str) or not isinstance(password, str):
                    raise ValueError()
            except (ValueError, KeyError, TypeError):
                return self.reply(400, {'error': 'Invalid JSON credentials'})
            try:
                if mode == 'vulnerable':
                    # Intentionally unsafe: the VAPT exercise demonstrates why.
                    query = f"SELECT id, username FROM users WHERE username='{username}' AND password='{password}'"
                    user = db.execute(query).fetchone()
                else:
                    user = db.execute('SELECT id, username FROM users WHERE username=? AND password=?',
                                      (username, password)).fetchone()
            except sqlite3.Error:
                return self.reply(400, {'error': 'Invalid query'})
            if user is None:
                return self.reply(401, {'error': 'Invalid credentials'})
            token = secrets.token_urlsafe(24)
            sessions[token] = user[0]
            return self.reply(200, {'token': token, 'user': user[1]})

        def do_GET(self):
            parsed = urlsplit(self.path)
            if parsed.path == '/':
                return self.reply(200, {'lab': 'Local VAPT training API', 'mode': mode,
                                        'routes': ['POST /login', 'GET /notes?id=1']})
            if parsed.path != '/notes':
                return self.reply(404, {'error': 'Not found'})
            token = self.headers.get('Authorization', '').removeprefix('Bearer ')
            owner = sessions.get(token)
            if owner is None:
                return self.reply(401, {'error': 'Authentication required'})
            try:
                note_id = int(parse_qs(parsed.query).get('id', ['0'])[0])
            except ValueError:
                return self.reply(400, {'error': 'Invalid note ID'})
            note = db.execute('SELECT owner, body FROM notes WHERE id=?', (note_id,)).fetchone()
            if note is None:
                return self.reply(404, {'error': 'Not found'})
            if mode == 'fixed' and note[0] != owner:
                return self.reply(403, {'error': 'Access denied'})
            return self.reply(200, {'id': note_id, 'body': note[1]})

    server = HTTPServer(('127.0.0.1', port), Handler)
    server.database = db
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['fixed', 'vulnerable'], default='fixed')
    parser.add_argument('--port', type=int, default=8000)
    args = parser.parse_args()
    server = create_server(args.mode, args.port)
    print(f'{args.mode} lab: http://127.0.0.1:{server.server_port}; Ctrl+C to stop', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        server.database.close()


if __name__ == '__main__':
    main()
