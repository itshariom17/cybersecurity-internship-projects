"""Reproduce findings against an ephemeral lab, then retest the fixes."""
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, build_opener, ProxyHandler
from urllib.error import HTTPError
from vapt.lab import create_server


def assess(mode):
    server = create_server(mode)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    opener = build_opener(ProxyHandler({}))
    evidence = []

    def request(label, path, body=None, token=None):
        headers = {'Content-Type': 'application/json'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        req = Request(base + path, data=json.dumps(body).encode() if body is not None else None, headers=headers)
        try:
            response = opener.open(req, timeout=5)
        except HTTPError as error:
            response = error
        with response:
            result = json.loads(response.read())
            status = response.status
        evidence.append({'test': label, 'method': req.get_method(), 'path': path,
                         'request_body': body, 'status': status,
                         'response': {k: ('[redacted session token]' if k == 'token' else v) for k, v in result.items()}})
        return status, result

    try:
        request('service_enumeration', '/')
        request('unauthenticated_access', '/notes?id=2')
        request('invalid_login', '/login', {'username': 'alice', 'password': 'wrong'})
        request('sql_injection_login_bypass', '/login', {'username': "alice' -- ", 'password': 'wrong'})
        _, login = request('valid_login', '/login', {'username': 'alice', 'password': 'Alice-lab-only!'})
        request('own_note', '/notes?id=1', token=login['token'])
        request('idor_other_users_note', '/notes?id=2', token=login['token'])
        request('missing_note', '/notes?id=999', token=login['token'])
        request('malformed_note_id', '/notes?id=abc', token=login['token'])
        return {'mode': mode, 'scope': 'Ephemeral 127.0.0.1 lab created by this process', 'evidence': evidence}
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()
        server.database.close()


def main():
    results = {'generated_utc': datetime.now(timezone.utc).isoformat(),
               'runs': [assess('vulnerable'), assess('fixed')]}
    target = Path('vapt/results.json')
    target.write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    for run in results['runs']:
        print(run['mode'])
        for test in run['evidence']:
            print(f"  {test['test']}: HTTP {test['status']}")
    print(f'Evidence saved to {target}')


if __name__ == '__main__':
    main()
